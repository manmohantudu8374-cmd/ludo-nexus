# Google Play Store Listing — LUDO NEXUS

**App name (≤30):** Ludo Nexus: Neon Board Game
**Short description (≤80):** Neon Ludo with AI, local multiplayer & Speed mode. Roll. Race. Conquer.
**Category:** Games → Board  |  **Tags:** Board, Casual, Multiplayer (local)
**Contact email / Privacy policy URL:** your email / https://YOUR-DOMAIN.com/privacy.html

## Full description (≤4000)
LUDO NEXUS — Roll. Race. Conquer.

Experience Ludo reimagined with a futuristic neon look. Roll the 3D dice, race your four tokens around the glowing board and capture your rivals!

★ GAME MODES
• Quick Play — jump in against computer players
• AI Battle — Easy, Medium, Hard or Expert opponents
• Local Multiplayer — 2, 3 or 4 players on one device
• Speed Ludo — faster moves, fewer safe cells

★ REAL LUDO RULES
• Roll a 6 to leave base, bonus roll on 6
• Capture opponents on unsafe cells, safe cells protect you
• Optional rules: capture bonus, three-six penalty, safe-zone protection

★ BUILT FOR MOBILE
• Smooth step-by-step token animation
• Save and resume your game
• Works offline, no sign-up, no ads
• Sound, music, haptic and reduced-motion options
• Profile, XP levels, achievements and match history

Download LUDO NEXUS and start your next winning streak!

## Console answers
- **Ads:** No  |  **In-app purchases:** No  |  **Account required:** No
- **Data safety:** No data collected or shared (all data stays on device)
- **Content rating (IARC):** no violence/gambling/user-generated content → expect "Everyone"
- **Target audience:** 13+ recommended (avoids Families-policy requirements); Not primarily for children
## Assets in this folder
- play-icon-512.png (512×512 app icon)
- feature-graphic-1024x500.png (feature graphic)
- Screenshots: YOU must capture 2–8 phone screenshots (min 320px, 16:9 or 9:16) of menu, setup, board, victory. Open /play/ on a phone or DevTools device mode and screenshot.
